export const environment = {
  production:false,
  firebaseAPIKey:'AIzaSyCgZpa69S4Mt_o_x8QIrm6S7mYE-QWbE1o',
  firebase: {
    apiKey: "AIzaSyCgZpa69S4Mt_o_x8QIrm6S7mYE-QWbE1o",
    authDomain: "mindshare-3ab39.firebaseapp.com",
    databaseURL: "https://mindshare-3ab39-default-rtdb.firebaseio.com",
    projectId: "mindshare-3ab39",
    storageBucket: "mindshare-3ab39.appspot.com",
    messagingSenderId: "1026892817254",
    appId: "1:1026892817254:web:34f55c8c9e0fe7e3d6dea7",
    measurementId: "G-K32GDX0Z5Y"
  }
}
