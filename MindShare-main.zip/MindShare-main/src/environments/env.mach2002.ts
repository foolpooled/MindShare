export const environment = {
    production:false,
    firebaseAPIKey:'AIzaSyALDE8UF8Hs3Cd1Hiy8VbP9vB3AYS2GKow',
       firebase : {
    apiKey: "AIzaSyALDE8UF8Hs3Cd1Hiy8VbP9vB3AYS2GKow",
    authDomain: "mindshare-e5200.firebaseapp.com",
    projectId: "mindshare-e5200",
    storageBucket: "mindshare-e5200.appspot.com",
    messagingSenderId: "432451289126",
    appId: "1:432451289126:web:ec4aa946d4da793f3d26e7",
    measurementId: "G-KM1SE031EH"
  },
  }
  